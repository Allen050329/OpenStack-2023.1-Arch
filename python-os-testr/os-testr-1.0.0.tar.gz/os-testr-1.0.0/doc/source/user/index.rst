=====
Usage
=====

This section contains the documentation for each of tools packaged in os-testr

.. toctree::
   :maxdepth: 2

   ostestr
   subunit_trace
   subunit2html
   generate_subunit
   history
