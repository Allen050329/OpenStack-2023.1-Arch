============
Installation
============

At the command line::

    $ pip install os-testr

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv os-testr
    $ pip install os-testr
